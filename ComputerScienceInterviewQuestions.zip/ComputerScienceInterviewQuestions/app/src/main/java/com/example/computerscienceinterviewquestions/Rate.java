package com.example.computerscienceinterviewquestions;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class Rate extends AppCompatActivity {
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
}
