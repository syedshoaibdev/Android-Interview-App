package com.example.computerscienceinterviewquestions;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class MainActivity extends AppCompatActivity {
    Button b1, b2,b3,b4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = findViewById(R.id.btn1);
        b2 = findViewById(R.id.btn2);
        b3 = findViewById(R.id.btn3);
        b4 = findViewById(R.id.btn4);



        Toolbar toolbar1;
        toolbar1 =findViewById(R.id.tool);
        setSupportActionBar(toolbar1);


        //btn  1
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent view = new Intent(MainActivity.this, question.class);
                startActivity(view);
                Toast toast = Toast.makeText(getApplicationContext(), "Show Questions", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
            }
        });

        //btn2
        b2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Intent view = new Intent(MainActivity.this, Tough.class);
                startActivity(view);
                Toast toast = Toast.makeText(getApplicationContext(), "Tough Questions", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();

            }
        });


        b3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    Uri uri1 = Uri.parse("market://search?q=Sriyank");
                    Intent gotomarket = new Intent(Intent.ACTION_VIEW, uri1);
                    startActivity(gotomarket);
                }
                catch (ActivityNotFoundException e){
                    Uri uri1 = Uri.parse("http://play.google.com/store/search?q=Sriyank");
                    Intent gotomarket = new Intent(Intent.ACTION_VIEW, uri1);
                    startActivity(gotomarket);
                }

                Toast toast = Toast.makeText(getApplicationContext(), "See Other App", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();

            }
        });


        b4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                try {
                    Uri uri1 = Uri.parse("market://details?id" + getPackageName());
                    Intent gotomarket = new Intent(Intent.ACTION_VIEW, uri1);
                    startActivity(gotomarket);
                }
                catch (ActivityNotFoundException e){
                    Uri uri1 = Uri.parse("http://play.google.com/store/apps/details?id" + getPackageName());
                    Intent gotomarket = new Intent(Intent.ACTION_VIEW, uri1);
                    startActivity(gotomarket);
                }

                Toast toast = Toast.makeText(getApplicationContext(), "Rate Over App", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();

            }
        });







    }


}


