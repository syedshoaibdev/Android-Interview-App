package com.example.computerscienceinterviewquestions;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Locale;

import static com.example.computerscienceinterviewquestions.R.array.simple_ques;

public class question<simple_questions> extends AppCompatActivity {

                       /*Button & Textview initialize */
       TextView tvquestion;
       TextView tvanswer;
       TextView tvtotalllength_yy;
       TextView tvpresentindex_xx;
       Button bleft;
       Button bright;
       Button  bshow;
       Button  btspeak;
       Button  bstopmute;
       TextToSpeech tts_object;


    /* Get array from XML file */

      int index;
      int result;
      private  static final String default_answer="Press \"A\" button for the Answer";
      String[]  simple_questions,simple_answers;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
                       /*Starting toolbar*/
        Toolbar toolbar=findViewById(R.id.tool);
        setSupportActionBar(toolbar);
        TextView tv_category=findViewById(R.id.tv_questions_titlebar);
        tv_category.setText("Simple Questions");
        btspeak=findViewById(R.id.bspeak);
        bstopmute=findViewById(R.id.bsto);



                         /* Set Button & TextView  Ids*/
        tvquestion = findViewById(R.id.tvquestion);
        tvtotalllength_yy= findViewById(R.id.tvyy);
        tvpresentindex_xx= findViewById(R.id.tvxx);
        bright= findViewById(R.id.bright);
        bleft= findViewById(R.id.bleft);
        bshow= findViewById(R.id.bshowanswer);
        tvanswer=findViewById(R.id.tvanswer);

             simple_questions = getResources().getStringArray(simple_ques);
                 simple_answers = getResources().getStringArray(R.array.simple_ans1);
        /*  Setting the value of variables*/
        index=0;
        tvquestion.setText(simple_questions[index]);
        tvanswer.setText(default_answer);
        tvpresentindex_xx.setText(String.valueOf(index+1));
        tvtotalllength_yy.setText("/"+ simple_questions.length);
                          /* Implement On Click Listener*/
        bleft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvanswer.setText(default_answer);
                index--;
                if(index==-1){
                    index=simple_questions.length-1;
                    tvquestion.setText(simple_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));
                }
               else {
                    tvquestion.setText(simple_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));

                }
            }
        });
        bright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvanswer.setText(default_answer);
                index++;
                if(index==simple_questions.length){
                    index=0;
                    tvquestion.setText(simple_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));
                }
               else {
                    tvquestion.setText(simple_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));

                }
            }
        });
        bshow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                tvanswer.setText(simple_answers[index]);
            }
        });
                         /* Adding TextToSpeech*/




        tts_object=new TextToSpeech(question.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status!=TextToSpeech.ERROR){
                     result=tts_object.setLanguage(Locale.US);
                }
                else {
                    Toast.makeText(getApplicationContext(),"Feature not Supportes In Your Device",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btspeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               if(result==TextToSpeech.LANG_MISSING_DATA || result==TextToSpeech.LANG_NOT_SUPPORTED){

                   Toast.makeText(getApplicationContext(),"Language Not Available",Toast.LENGTH_SHORT).show();

               }
               else {
                   if(tvanswer.getText().toString().equals(default_answer)){

                   }

                   else {
                       tts_object.speak(simple_answers[index],TextToSpeech.QUEUE_FLUSH,null);
                   }
               }

            }

        });

        bstopmute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tts_object!=null) {
                    tts_object.stop();
                }

            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts_object!=null) {
            tts_object.stop();
            tts_object.shutdown();
        }

    }
}
