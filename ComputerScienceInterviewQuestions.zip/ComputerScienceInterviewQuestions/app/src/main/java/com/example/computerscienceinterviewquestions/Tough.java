package com.example.computerscienceinterviewquestions;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Locale;

public class Tough extends AppCompatActivity {
    /*Button & Textview initialize */
    TextView tvquestion;
    TextView tvanswer;
    TextView tvtotalllength_yy;
    TextView tvpresentindex_xx;
    Button bleft;
    Button bright;
    Button  bshow;
    int index;
    Button  btspeak;
    Button  bstopmute;
    TextToSpeech tts_object;
    int result;
    private  static final String default_answer="Press \"A\" button for the Answer";
    String[] tough_questions,tough_answers;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_question);
                        /* Starting tool bar*/
        Toolbar toolbar=findViewById(R.id.tool);
        setSupportActionBar(toolbar);
        btspeak=findViewById(R.id.bspeak);
        bstopmute=findViewById(R.id.bsto);
        TextView tv_category=findViewById(R.id.tv_questions_titlebar);
        tv_category.setText("Tough Questions");
                        /* Get array from XML file */
        tough_questions=getResources().getStringArray(R.array.difficult_ques);
        tough_answers=getResources().getStringArray(R.array.difficult_ans);

                       /* Set Button & TextView  Ids*/
        tvquestion = findViewById(R.id.tvquestion);
        tvtotalllength_yy= findViewById(R.id.tvyy);
        tvpresentindex_xx= findViewById(R.id.tvxx);
        bright= findViewById(R.id.bright);
        bleft= findViewById(R.id.bleft);
        bshow= findViewById(R.id.bshowanswer);
        tvanswer=findViewById(R.id.tvanswer);
        /*  set the values*/
          index = 0;
        tvquestion.setText(tough_questions[index]);
        tvanswer.setText("Press \"A\" button for the Answer");
        tvpresentindex_xx.setText(String.valueOf(index +1));
        tvtotalllength_yy.setText("/"+tough_questions.length);


                      /* Implement On Click Listner*/
        bleft.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvanswer.setText("Press \"A\" button for the Answer");
                index--;
                if(index ==-1){
                    index =tough_questions.length-1;
                    tvquestion.setText(tough_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));

                }
                else {
                    tvquestion.setText(tough_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));
                }

            }
        });
        bright.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvanswer.setText("Press \"A\" button for the Answer");
                index++;
                if(index==tough_questions.length){
                    index=0;
                    tvquestion.setText(tough_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));
                }
                else {
                    tvquestion.setText(tough_questions[index]);
                    tvpresentindex_xx.setText(String.valueOf(index+1));
                }

            }
        });
        bshow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                tvanswer.setText(tough_answers[index]);

            }
        });

        tts_object=new TextToSpeech(Tough.this, new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {
                if(status!=TextToSpeech.ERROR){
                    result=tts_object.setLanguage(Locale.US);
                }
                else {
                    Toast.makeText(getApplicationContext(),"Feature not Supportes In Your Device",Toast.LENGTH_SHORT).show();
                }
            }
        });

        btspeak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(result==TextToSpeech.LANG_MISSING_DATA || result==TextToSpeech.LANG_NOT_SUPPORTED){

                    Toast.makeText(getApplicationContext(),"Language Not Available",Toast.LENGTH_SHORT).show();

                }
                else {
                    if(tvanswer.getText().toString().equals(default_answer)){

                    }

                    else {
                        tts_object.speak(tough_answers[index],TextToSpeech.QUEUE_FLUSH,null);
                    }
                }

            }

        });

        bstopmute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tts_object!=null) {
                    tts_object.stop();
                }

            }
        });


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (tts_object!=null) {
            tts_object.stop();
            tts_object.shutdown();
        }
    }


}
